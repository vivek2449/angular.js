require('../../../../lib/bootstrap-local');
require('./type_checker.ts');
